public static class Constants
{
  public const float Epsilon = 0.001f;
}