﻿namespace CodeBase.Logic.Points
{
    public interface IPoint
    {
        void TakePoint();
        void ReleasePoint();
    }
}