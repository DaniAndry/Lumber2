﻿namespace CodeBase.Logic.Points
{
    public class MoneyMovePoint : IPoint
    {
        public bool IsBusy { get; private set; }
        
        public void TakePoint()
        {
  
        }

        public void ReleasePoint()
        {

        }
    }
}