using UnityEngine;

namespace Logic
{
    public class ItemSpawner : MonoBehaviour
    {
        [SerializeField] private GameObject itemPrefab;
        [SerializeField] private ItemMovePoints _items;

        private void Start()
        {
            
        }

        private void SpawnItems()
        {
        }
    }
}