﻿namespace Logic.Place
{
    public class MoneyLoadPlace : ILoadable
    {
        public void Load()
        {

        }
    }
}