﻿namespace Logic.Place
{
    public interface ILoadable
    {
        void Load();
    }
}