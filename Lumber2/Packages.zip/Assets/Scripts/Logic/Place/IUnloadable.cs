﻿namespace Logic.Place
{
    public interface IUnloadable
    {
        void Unload();
    }
}