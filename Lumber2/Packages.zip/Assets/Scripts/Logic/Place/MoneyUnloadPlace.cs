﻿namespace Logic.Place
{
    public class MoneyUnloadPlace : IUnloadable
    {
        public void Unload()
        {
            
        }
    }
}