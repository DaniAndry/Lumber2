﻿using Logic.Place;

public class TreeUnloadPlace : IUnloadable
{
    public void Unload()
    {
        throw new System.NotImplementedException();
    }
}