﻿namespace Logic.Place
{
    public class TreeLoadPlace : ILoadable
    {
        public void Load()
        {
        }
    }
}