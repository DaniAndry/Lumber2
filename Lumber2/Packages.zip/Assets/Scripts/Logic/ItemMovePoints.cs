﻿using System.Collections.Generic;
using CodeBase.Logic.Points;

namespace Logic
{
    internal class ItemMovePoints
    {
        private List<IPoint> _points; 
    }
}